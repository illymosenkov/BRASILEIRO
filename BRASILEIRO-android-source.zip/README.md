# BRASILEIRO 🇧🇷

Android starter app for learning Brazilian Portuguese.

## Build
Run `gradle assembleDebug` with JDK 17 and Android SDK 35.

GitHub Actions builds a debug APK on every push to `main` and on manual workflow dispatch. Download it from the workflow run's **Artifacts** section.
